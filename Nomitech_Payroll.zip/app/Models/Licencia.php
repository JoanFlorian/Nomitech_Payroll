<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Licencia extends Model
{
    use HasFactory;

    protected $table = 'licencia';
    protected $primaryKey = 'id';
    public $timestamps = true;

    protected $fillable = [
        'empresa_id',
        'plan_id',
        'estado',
        'fecha_inicio',
        'fecha_fin',
    ];

    protected $casts = [
        'fecha_inicio' => 'date',
        'fecha_fin' => 'date',
    ];

    public function getEstadoAttribute()
    {
        if (!$this->fecha_fin) {
            return 'pendiente_pago';
        }

        $hoy = Carbon::now()->startOfDay();
        $fin = Carbon::parse($this->fecha_fin)->startOfDay();

        if ($fin->isPast()) {
            return 'vencida';
        }

        // diffInDays returns absolute difference. 
        // We check if the difference is 15 days or less.
        if ($hoy->diffInDays($fin, false) <= 15) {
            return 'por_vencer';
        }

        return 'activa';
    }

    public function empresa()
    {
        return $this->belongsTo(Empresa::class, 'empresa_id', 'id_empresa');
    }

    public function plan()
    {
        return $this->belongsTo(Plan::class, 'plan_id', 'id');
    }

    public function pagos()
    {
        return $this->hasMany(Pago::class, 'licencia_id', 'id');
    }
}
