<style>
    /* Fuente y fondo general */
    body {
        font-family: 'Inter', sans-serif;
        background-color: #F7F9FC;
    }

    /* Contenedor principal de login */
    .login-container {
        display: grid;
        grid-template-columns: 1fr 1fr;
        min-height: 100vh;
    }

    /* Columna izquierda */
    .left-column {
        position: relative;
        overflow: hidden;
    }

    /* Shapes de la columna izquierda */
    .shape {
        position: absolute;
        border-radius: 50%;
        background-color: rgba(255, 255, 255, 0.05);
        pointer-events: none;
    }
    .shape-1 { width: 200px; height: 200px; top: -50px; left: -50px; background-color: rgba(255, 255, 255, 0.1); }
    .shape-2 { width: 300px; height: 300px; bottom: -100px; right: -100px; }
    .shape-3 { width: 120px; height: 120px; bottom: 150px; left: 40px; background-color: rgba(38, 166, 154, 0.1); }
    .shape-4 { width: 50px; height: 50px; top: 200px; right: 50px; }

    /* Líneas decorativas columna izquierda */
    .line {
        position: absolute;
        background-color: rgba(255, 255, 255, 0.1);
        pointer-events: none;
    }
    .line-1 { width: 1px; height: 250px; top: 100px; left: 20%; transform: rotate(20deg); }
    .line-2 { width: 1px; height: 300px; bottom: 50px; right: 25%; transform: rotate(-30deg); }

    /* Shapes columna derecha */
    .right-shape {
        position: absolute;
        pointer-events: none;
    }
    .right-shape-1 { width: 450px; height: 450px; top: -180px; right: -180px; background-color: #B2D7F7; border-radius: 50%; opacity: 0.6; }
    .right-shape-2 { width: 250px; height: 250px; bottom: -120px; left: -120px; border-radius: 40% 60% 60% 40% / 70% 30% 70% 30%; background-color: #8DD3CC; opacity: 0.7; transform: rotate(30deg); }
    .right-shape-3 { width: 120px; height: 120px; top: 45%; left: 10%; border: 2px solid #A3D9D4; border-radius: 50%; opacity: 0.9; }
    .right-shape-4 { width: 220px; height: 220px; bottom: 50px; right: -110px; border-radius: 60% 40% 30% 70% / 60% 30% 70% 40%; background-color: #C5CFD9; opacity: 0.8; transform: rotate(-30deg); }
    .right-shape-5 { width: 50px; height: 50px; top: 15%; right: 25%; background-color: #8DD3CC; border-radius: 50%; opacity: 0.8; }

    /* Líneas columna derecha */
    .right-line {
        position: absolute;
        pointer-events: none;
    }
    .right-line-1 { width: 1.5px; height: 150px; top: 20%; left: 20%; transform: rotate(45deg); background-color: #A3D9D4; opacity: 0.9; }
    .right-line-2 { width: 200px; height: 1.5px; bottom: 30%; right: 10%; transform: rotate(-15deg); background-color: #C5CFD9; opacity: 0.9; }

    /* Responsive */
    @media (max-width: 768px) {
        .login-container {
            grid-template-columns: 1fr;
        }
        .left-column {
            display: none;
        }
    }
</style>
    