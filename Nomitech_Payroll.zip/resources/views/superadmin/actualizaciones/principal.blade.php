@extends('layouts.superadmin')

@section('content')
    <div class="px-8 pt-3 pb-6">
        <!-- DEBUG INFO PARA DUSK -->
        <div id="dusk-success-check" style="display:none">{{ session('success') }}</div>
        <div id="dusk-auth-check" style="display:none">{{ auth()->check() ? 'logged_in' : 'guest' }}</div>

        <!-- ALERTAS DE ÉXITO/ERROR -->
        @if ($message = Session::get('success'))
            <div id="alertExito"
                class="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg shadow-sm flex items-center gap-3 animate-pulse">
                <i class="bi bi-check-circle text-green-600 text-xl"></i>
                <div>
                    <p class="text-green-800 font-semibold">¡Éxito!</p>
                    <p class="text-green-700 text-sm">{{ $message }}</p>
                </div>
                <button onclick="cerrarAlerta('alertExito')" class="ml-auto text-green-600 hover:text-green-800">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
        @endif

        @if ($message = Session::get('error'))
            <div id="alertError" class="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg shadow-sm flex items-center gap-3">
                <i class="bi bi-exclamation-circle text-red-600 text-xl"></i>
                <div>
                    <p class="text-red-800 font-semibold">¡Error!</p>
                    <p class="text-red-700 text-sm">{{ $message }}</p>
                </div>
                <button onclick="cerrarAlerta('alertError')" class="ml-auto text-red-600 hover:text-red-800">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
        @endif

        @if ($errors->any())
            <div id="alertError" class="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg shadow-sm flex items-center gap-3">
                <i class="bi bi-exclamation-circle text-red-600 text-xl"></i>
                <div>
                    <p class="text-red-800 font-semibold">Error de Validación</p>
                    <ul class="list-disc list-inside text-red-700 text-sm">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
                <button onclick="cerrarAlerta('alertError')" class="ml-auto text-red-600 hover:text-red-800">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
        @endif

        <h1 class="text-3xl font-bold text-gray-900">
            Módulo de Actualizaciones
        </h1>
        <p class="text-gray-500 mt-1 mb-3">
            Gestiona la configuración básica del sistema de nómina y facturación.
        </p>

        <!-- GRID DE CARDS -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-2">

            @foreach($modulos as $modulo)
                <div class="bg-white rounded-lg shadow-sm border p-4 flex flex-col justify-between">

                    <div>
                        <div class="w-10 h-10 flex items-center justify-center rounded-md bg-blue-100 text-blue-900 mb-3">
                            <i class="bi {{ $modulo['icono'] }} text-lg"></i>
                        </div>

                        <h3 class="font-semibold text-base text-gray-900 leading-tight">
                            {{ $modulo['titulo'] }}
                        </h3>
                        <p class="text-xs text-gray-500 mt-1 leading-snug">
                            {{ $modulo['desc'] }}
                        </p>
                    </div>

                    <div class="flex gap-2 mt-4">
                        <button type="button" dusk="button-add-{{ strtolower($modulo['titulo']) }}"
                            onclick="openAddModal('{{ strtolower($modulo['titulo']) }}')"
                            class="bg-blue-900 text-white px-3 py-1.5 rounded-md text-xs flex items-center gap-1 hover:bg-blue-800">
                            <i class="bi bi-plus-lg text-xs"></i> Agregar
                        </button>
                        <button type="button" dusk="button-edit-{{ strtolower($modulo['titulo']) }}"
                            onclick="abrirEdicion('{{ strtolower($modulo['titulo']) }}')"
                            class="border px-3 py-1.5 rounded-md text-xs flex items-center gap-1 hover:bg-gray-50 transition">
                            <i class="bi bi-pencil text-xs"></i> Editar
                        </button>
                        <button type="button" onclick="descargarExcel('{{ strtolower($modulo['titulo']) }}')"
                            class="bg-green-600 text-white px-3 py-1.5 rounded-md text-xs flex items-center gap-1 hover:bg-green-700 transition"
                            title="Descargar Excel">
                            <i class="bi bi-file-earmark-arrow-down text-xs"></i> Descargar
                        </button>
                    </div>

                </div>
            @endforeach

        </div>

        <div class="mt-6">
            {{ $modulos->links() }}
        </div>

    </div>

    <!-- MODAL DE LISTADO PARA EDICIÓN -->
    <div id="modalListadoEdicion" class="fixed inset-0 bg-black/60 hidden items-center justify-center z-50 p-4 backdrop-blur-sm">
        <div
            class="bg-white rounded-2xl w-full max-w-6xl p-8 relative shadow-2xl border border-gray-100 max-h-[90vh] flex flex-col">

            <!-- Botón cerrar -->
            <button onclick="closeListadoModal()"
                class="absolute top-5 right-5 w-9 h-9 flex items-center justify-center rounded-full bg-gray-100 text-gray-500 hover:bg-red-100 hover:text-red-500 transition-all duration-200">
                <i class="bi bi-x-lg text-lg"></i>
            </button>

            <!-- Header con icono dinámico -->
            <div class="mb-6 pb-5 border-b border-gray-200">
                <div class="flex items-center gap-4">
                    <div id="modalIcono"
                        class="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-lg">
                        <i class="bi bi-table text-white text-xl"></i>
                    </div>
                    <div>
                        <h2 id="modalTitulo" class="text-2xl font-bold text-gray-900">Edición</h2>
                        <p id="modalSubtitulo" class="text-gray-500 text-sm mt-0.5">Selecciona un registro para editar</p>
                    </div>
                </div>
            </div>

            <!-- Contenido scrollable -->
            <div id="modalContenido" class="flex-1 overflow-y-auto text-sm text-gray-700 pr-1">
                <!-- Aquí se cargan los datos -->
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    @if ($errors->any())
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                if (!window.Swal) {
                    return;
                }

                Swal.fire({
                    icon: 'warning',
                    title: 'Errores de validación',
                    html: `<ul style="text-align:left; margin:0; padding-left:1rem;">@foreach ($errors->all() as $error)<li>{{ addslashes($error) }}</li>@endforeach</ul>`,
                    confirmButtonText: 'Entendido',
                    confirmButtonColor: '#2563eb'
                });
            });
        </script>
    @endif

    <script>
        // Mapeo de nombre de módulo a tipo de configuración
        const moduloATipo = {
            'ciudades': 'ciudades',
            'tipos de documento': 'tipos_de_documento',
            'bancos': 'bancos',
            'roles': 'roles_nombres',
            'tipos de contrato': 'tipos_de_contrato',
            'eps': 'eps',
            'arl': 'arl',
            'empresas': 'empresas',
            'departamentos': 'departamentos',
            'estados': 'estados',
            'formas de pago': 'formas_de_pago',
            'métodos de pago': 'metodos_de_pago',
            'países': 'paises',
            'roles de sistema': 'roles',
            'tipos hora recargo': 'tipos_hora_recargo'
        };

        const departamentosJS = @json($departamentos->map(fn($d) => ['id' => $d->id_departamento, 'nombre' => $d->nombre]));
        const ciudadesJS = @json(($ciudades ?? collect())->map(fn($c) => ['id' => $c->id_ciudad, 'nombre' => $c->nombre]));

        const configuracionesCliente = {
            ciudades: {
                tipo: 'ciudades',
                campos: [
                    { clave: 'codigo', label: 'Código', tipo: 'text', icono: 'bi-hash', requerido: true },
                    { clave: 'nombre', label: 'Nombre', tipo: 'text', icono: 'bi-pin-map', requerido: true },
                    { clave: 'id_departamento', label: 'Departamento', tipo: 'select', icono: 'bi-map', requerido: true, opciones: departamentosJS }
                ],
                campoId: 'id_ciudad',
                ruta: '/superadmin/actualizar/:id',
                colores: { icono: 'from-orange-400 to-orange-600', boton: 'from-orange-500 to-orange-600' }
            },
            tipos_de_documento: {
                tipo: 'tipos_de_documento',
                campos: [
                    { clave: 'nombre', label: 'Nombre', tipo: 'text', icono: 'bi-person-badge', requerido: true }
                ],
                campoId: 'id_tipo_doc',
                ruta: '/superadmin/actualizar/:id',
                colores: { icono: 'from-green-400 to-green-600', boton: 'from-green-500 to-green-600' }
            },
            bancos: {
                tipo: 'bancos',
                campos: [
                    { clave: 'id_banco', label: 'Código', tipo: 'text', icono: 'bi-hash', requerido: true },
                    { clave: 'nombre', label: 'Nombre', tipo: 'text', icono: 'bi-bank', requerido: true },
                    { clave: 'telefono', label: 'Teléfono', tipo: 'text', icono: 'bi-telephone' },
                    { clave: 'direccion', label: 'Dirección', tipo: 'text', icono: 'bi-geo-alt' }
                ],
                campoId: 'id_banco',
                ruta: '/superadmin/actualizar/:id',
                colores: { icono: 'from-purple-400 to-purple-600', boton: 'from-purple-500 to-purple-600' }
            },
            roles_nombres: {
                tipo: 'roles_nombres',
                campos: [
                    { clave: 'nombre', label: 'Nombre', tipo: 'text', icono: 'bi-briefcase', requerido: true },
                    { clave: 'descripcion', label: 'Descripción', tipo: 'textarea', icono: 'bi-file-text' }
                ],
                campoId: 'id_rol',
                ruta: '/superadmin/actualizar/:id',
                colores: { icono: 'from-indigo-400 to-indigo-600', boton: 'from-indigo-500 to-indigo-600' }
            },
            tipos_de_contrato: {
                tipo: 'tipos_de_contrato',
                campos: [
                    { clave: 'nombre', label: 'Nombre', tipo: 'text', icono: 'bi-file-earmark', requerido: true },
                    {
                        clave: 'seguridad_social', label: '¿Incluye Seguridad Social?', tipo: 'select', icono: 'bi-check-circle', opciones: [
                            { id: 0, nombre: 'No' },
                            { id: 1, nombre: 'Sí' }
                        ]
                    }
                ],
                campoId: 'id_tipo_contrato',
                ruta: '/superadmin/actualizar/:id',
                colores: { icono: 'from-cyan-400 to-cyan-600', boton: 'from-cyan-500 to-cyan-600' }
            },
            eps: {
                tipo: 'eps',
                campos: [
                    { clave: 'id_eps', label: 'Código', tipo: 'text', icono: 'bi-hash', requerido: true },
                    { clave: 'nombre', label: 'Nombre', tipo: 'text', icono: 'bi-heart-pulse', requerido: true },
                    { clave: 'telefono', label: 'Teléfono', tipo: 'text', icono: 'bi-telephone' },
                    { clave: 'direccion', label: 'Dirección', tipo: 'text', icono: 'bi-geo-alt' }
                ],
                campoId: 'id_eps',
                ruta: '/superadmin/actualizar/:id',
                colores: { icono: 'from-red-400 to-red-600', boton: 'from-red-500 to-red-600' }
            },
            arl: {
                tipo: 'arl',
                campos: [
                    { clave: 'id_arl', label: 'Código', tipo: 'text', icono: 'bi-hash', requerido: true },
                    { clave: 'nombre', label: 'Nombre', tipo: 'text', icono: 'bi-shield-check', requerido: true },
                    { clave: 'telefono', label: 'Teléfono', tipo: 'text', icono: 'bi-telephone' },
                    { clave: 'direccion', label: 'Dirección', tipo: 'text', icono: 'bi-geo-alt' }
                ],
                campoId: 'id_arl',
                ruta: '/superadmin/actualizar/:id',
                colores: { icono: 'from-yellow-400 to-yellow-600', boton: 'from-yellow-500 to-yellow-600' }
            },
            empresas: {
                tipo: 'empresas',
                campos: [
                    { clave: 'nit', label: 'NIT', tipo: 'text', icono: 'bi-hash', requerido: true },
                    { clave: 'razon_social', label: 'Razón Social', tipo: 'text', icono: 'bi-card-text', requerido: true },
                    { clave: 'id_ciudad', label: 'Ciudad', tipo: 'select', icono: 'bi-geo-alt', requerido: true, opciones: ciudadesJS },
                    { clave: 'doc_representante', label: 'Doc. Representante', tipo: 'text', icono: 'bi-person-badge' },
                    { clave: 'direccion', label: 'Dirección', tipo: 'text', icono: 'bi-map-pin' },
                    { clave: 'correo', label: 'Correo', tipo: 'email', icono: 'bi-envelope' },
                    { clave: 'telefono', label: 'Teléfono', tipo: 'text', icono: 'bi-telephone' }
                ],
                campoId: 'id_empresa',
                ruta: '/superadmin/actualizar/:id',
                colores: { icono: 'from-blue-400 to-blue-600', boton: 'from-blue-500 to-blue-600' }
            },
            departamentos: {
                tipo: 'departamentos',
                campos: [
                    { clave: 'codigo', label: 'Código', tipo: 'text', icono: 'bi-hash', requerido: true },
                    { clave: 'nombre', label: 'Nombre', tipo: 'text', icono: 'bi-map', requerido: true }
                ],
                campoId: 'id_departamento',
                ruta: '/superadmin/actualizar/:id',
                colores: { icono: 'from-teal-400 to-teal-600', boton: 'from-teal-500 to-teal-600' }
            },
            estados: {
                tipo: 'estados',
                campos: [
                    { clave: 'nombre', label: 'Nombre', tipo: 'text', icono: 'bi-info-circle', requerido: true }
                ],
                campoId: 'id_estado',
                ruta: '/superadmin/actualizar/:id',
                colores: { icono: 'from-lime-400 to-lime-600', boton: 'from-lime-500 to-lime-600' }
            },
            formas_de_pago: {
                tipo: 'formas_de_pago',
                campos: [
                    { clave: 'nombre', label: 'Nombre', tipo: 'text', icono: 'bi-credit-card', requerido: true }
                ],
                campoId: 'id_forma_pago',
                ruta: '/superadmin/actualizar/:id',
                colores: { icono: 'from-fuchsia-400 to-fuchsia-600', boton: 'from-fuchsia-500 to-fuchsia-600' }
            },
            metodos_de_pago: {
                tipo: 'metodos_de_pago',
                campos: [
                    { clave: 'nombre', label: 'Nombre', tipo: 'text', icono: 'bi-wallet2', requerido: true }
                ],
                campoId: 'id_metodo_pago',
                ruta: '/superadmin/actualizar/:id',
                colores: { icono: 'from-rose-400 to-rose-600', boton: 'from-rose-500 to-rose-600' }
            },
            paises: {
                tipo: 'paises',
                campos: [
                    { clave: 'codigo_alfa2', label: 'Código', tipo: 'text', icono: 'bi-hash', requerido: true },
                    { clave: 'nombre', label: 'Nombre', tipo: 'text', icono: 'bi-globe', requerido: true }
                ],
                campoId: 'id_pais',
                ruta: '/superadmin/actualizar/:id',
                colores: { icono: 'from-sky-400 to-sky-600', boton: 'from-sky-500 to-sky-600' }
            },
            roles: {
                tipo: 'roles',
                campos: [
                    { clave: 'nombre', label: 'Nombre', tipo: 'text', icono: 'bi-shield-lock', requerido: true },
                    { clave: 'descripcion', label: 'Descripción', tipo: 'textarea', icono: 'bi-file-text' }
                ],
                campoId: 'id_rol',
                ruta: '/superadmin/actualizar/:id',
                colores: { icono: 'from-violet-400 to-violet-600', boton: 'from-violet-500 to-violet-600' }
            },
            tipos_hora_recargo: {
                tipo: 'tipos_hora_recargo',
                campos: [
                    { clave: 'nombre', label: 'Nombre', tipo: 'text', icono: 'bi-clock', requerido: true }
                ],
                campoId: 'id_tipo_hora_recargo',
                ruta: '/superadmin/actualizar/:id',
                colores: { icono: 'from-amber-400 to-amber-600', boton: 'from-amber-500 to-amber-600' }
            }
        };

        const estadoListadoEdicion = {
            tipo: null,
            q: '',
            debounce: null,
            requestId: 0,
        };

        function cargarListadoEdicion(page = 1) {
            if (!estadoListadoEdicion.tipo) {
                return;
            }

            const requestIdActual = ++estadoListadoEdicion.requestId;

            const params = new URLSearchParams();
            params.set('page', String(page));
            if (estadoListadoEdicion.q) {
                params.set('q', estadoListadoEdicion.q);
            }

            fetch(`/superadmin/actualizaciones/${estadoListadoEdicion.tipo}/datos?${params.toString()}`)
                .then(res => res.text())
                .then(html => {
                    if (requestIdActual !== estadoListadoEdicion.requestId) {
                        return;
                    }

                    document.getElementById('modalContenido').innerHTML = html;

                    const inputBuscar = document.getElementById('buscar-items');
                    if (inputBuscar) {
                        inputBuscar.value = estadoListadoEdicion.q;
                        inputBuscar.addEventListener('input', function () {
                            buscarListadoEdicion(this.value);
                        });
                    }
                })
                .catch(err => {
                    console.log(err);
                    document.getElementById('modalContenido').innerHTML = '<p class="text-red-600">No se pudo cargar el listado.</p>';
                });
        }

        function openListadoModal(modulo) {
            document.getElementById('modalListadoEdicion').classList.remove('hidden');
            document.getElementById('modalListadoEdicion').classList.add('flex');
            document.getElementById('modalTitulo').innerText = 'Datos de ' + modulo;

            // Convertir nombre de módulo a tipo
            const tipo = moduloATipo[modulo.toLowerCase()] || modulo.toLowerCase().replace(/\s+/g, '_').replace(/[óá]/g, 'o');
            estadoListadoEdicion.tipo = tipo;
            estadoListadoEdicion.q = '';
            cargarListadoEdicion(1);
        }

        function buscarListadoEdicion(valor) {
            estadoListadoEdicion.q = (valor || '').trim();

            if (estadoListadoEdicion.debounce) {
                clearTimeout(estadoListadoEdicion.debounce);
            }

            estadoListadoEdicion.debounce = setTimeout(() => {
                cargarListadoEdicion(1);
            }, 250);
        }

        function cambiarPaginaListadoEdicion(page) {
            const numeroPagina = Number(page);
            if (!Number.isInteger(numeroPagina) || numeroPagina < 1) {
                return;
            }

            cargarListadoEdicion(numeroPagina);
        }

        function abrirEdicion(modulo) {
            openListadoModal(modulo);
        }

        function closeListadoModal() {
            document.getElementById('modalListadoEdicion').classList.add('hidden');
            document.getElementById('modalListadoEdicion').classList.remove('flex');
        }

        function openAddModal(modulo) {
            const tipo = moduloATipo[modulo.toLowerCase()] || modulo.toLowerCase().replace(/\s+/g, '_').replace(/[óá]/g, 'o');
            const configuracion = configuracionesCliente[tipo];

            if (configuracion) {
                abrirModalAgregar(tipo, configuracion);
            }
        }

        function closeAddModal() {
            cerrarModalAgregar();
        }

        // Descargar Excel
        function descargarExcel(modulo) {
            const tipo = moduloATipo[modulo.toLowerCase()] || modulo.toLowerCase().replace(/\s+/g, '_').replace(/[óá]/g, 'o');
            window.location.href = `/superadmin/actualizaciones/${tipo}/exportar-excel`;
        }

        function cerrarAlerta(idAlerta) {
            const alerta = document.getElementById(idAlerta);
            if (alerta) {
                alerta.style.transition = 'opacity 0.3s ease-out';
                alerta.style.opacity = '0';
                setTimeout(() => {
                    alerta.remove();
                }, 300);
            }
        }

        // Desaparecer alertas automáticamente después de 3 segundos
        document.addEventListener('DOMContentLoaded', function () {
            const alertExito = document.getElementById('alertExito');
            const alertError = document.getElementById('alertError');

            if (alertExito) {
                setTimeout(() => cerrarAlerta('alertExito'), 3000);
            }
            if (alertError) {
                setTimeout(() => cerrarAlerta('alertError'), 3000);
            }
        });

    </script>

    @include('superadmin.actualizaciones.partials.agregar-generico')
    @include('superadmin.actualizaciones.partials.modal-edicion-generico')

@endsection